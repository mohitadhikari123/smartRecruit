import CandidateForm from "@/components/CandidateForm";

export default function CandidatesPage() {
  return (
    <div>
      <h1>Submit Your Resume</h1>
      <CandidateForm />
    </div>
  );
}

import CandidateForm from "@/components/CandidateForm";

export default function Home() {
  return (
    <main>
      <CandidateForm />
    </main>
  );
}
